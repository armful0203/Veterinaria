# Clinica veterinaria

Opcion 3 de la tarea: Mascota, Medicamento y Veterinario. PostgreSQL, Spring Boot y Java 27 (segun pom.xml).
Puerto: 9090. Los tres modelos son independientes, sin claves foraneas ni relaciones JPA.
Cada uno tiene sus clases en model, repository, services y controller, siguiendo Mascota.

## Preparacion y ejecucion

1. Instalar el JDK indicado en pom.xml y PostgreSQL. Configurar JAVA_HOME al JDK.
2. Abrir una terminal en esta carpeta (la que contiene pom.xml).
3. En una base vacia, ejecutar `psql -U postgres -d postgres -f database/script.sql`.
   El script crea el usuario de aplicacion kevin, la base veterinaria, tres tablas y cinco ejemplos por tabla.
   Requiere permisos administrativos para crear usuario y base. Usa comandos de psql, no Query Tool.
   Si ya existe kevin, conserva su clave actual: comprobar que coincida con application.properties.
   En tablas con datos existentes, no agrega los ejemplos ni borra datos.
4. Revisar src/main/resources/application.properties: conexion a localhost:5432/veterinaria,
   usuario kevin, clave de practica 123, ddl-auto=update. Cambiar la clave en ambos sitios si corresponde.
5. Ejecutar `.\mvnw.cmd spring-boot:run` en PowerShell o ejecutar VerterinariaApplication desde IntelliJ.
6. Abrir http://localhost:9090/api/mascota, /api/medicamento y /api/veterinario.

No se usa H2. Se mantiene la configuracion local que ya funcionaba.

## Endpoints CRUD

Estas cinco operaciones se aplican a cada ruta base: `/api/mascota`, `/api/medicamento`, `/api/veterinario`.

| Metodo | Ruta | Respuesta |
| --- | --- | --- |
| GET | ruta base | 200, lista JSON |
| GET | ruta base/{id} | 200 o 404 |
| POST | ruta base | 201 |
| PUT | ruta base/{id} | 200 o 404 |
| DELETE | ruta base/{id} | 204 o 404 |

## Situaciones especiales

| Metodo | Ruta | Comportamiento y codigos |
| --- | --- | --- |
| GET | /api/mascota/especie/{especie} | Filtro sin distinguir mayusculas; 200 |
| GET | /api/mascota/conteo-especies | Objeto con conteo por especie; 200 |
| GET | /api/mascota/dueno/{dueno} | Consulta existente conservada; 200 |
| GET | /api/mascota/cachorros | Edad menor o igual a 1; 200 |
| GET | /api/medicamento/stock-bajo?minimo=5 | Stock estrictamente menor al minimo; por defecto 5; 200 |
| GET | /api/medicamento/venta-libre | No requieren receta; 200 |
| PUT | /api/medicamento/{id}/despachar?cantidad=2 | Descuenta stock; 200, 400 si cantidad <= 0, 404 si no existe, 409 si no alcanza |
| GET | /api/veterinario/especialidad/{especialidad} | Solo disponibles de esa especialidad, sin distinguir mayusculas; 200 |
| GET | /api/veterinario/mas-experimentado | Mayor experiencia; empate por menor id; 200 o 404 si la tabla esta vacia |
| PUT | /api/veterinario/{id}/disponibilidad?valor=false | Cambia disponible; 200, 404, 409 si ya tenia ese valor |

Las reglas especiales estan en los servicios. Los controladores usan servicios, no repositorios.

## Postman

Importar postman/veterinaria.postman_collection.json y ejecutar la coleccion completa con Collection Runner.
baseUrl vale http://localhost:9090. Cada carpeta crea un registro temporal, guarda su ID, comprueba
CRUD y situaciones especiales y al final borra ese registro. Ejecutar en orden con la API encendida.
Las peticiones incluyen comprobaciones de estado HTTP y verificaciones del stock y la disponibilidad.
Hay casos 404 por modelo, 400 de cantidad y 409 de stock y disponibilidad.
No ejecutar en paralelo las peticiones de una carpeta. Si se interrumpe la ejecucion, puede quedar el registro temporal.

## Comprobacion y evidencias para entregar

La coleccion es ejecutable; su existencia no significa que sus pruebas ya hayan pasado.
Comprobar tambien /api/veterinario/mas-experimentado en una base de prueba sin veterinarios: debe devolver 404.
Ejecutar `.\mvnw.cmd test` para la prueba de contexto existente (requiere PostgreSQL configurado).
Para las siete pruebas unitarias de servicios sin base: `.\mvnw.cmd "-Dtest=MedicamentoServiceTests,VeterinarioServiceTests" test`.
Validacion realizada: compilacion correcta y siete pruebas unitarias de servicios aprobadas, sin fallos ni errores.
Se utilizo una copia local de Maven en modo offline porque el wrapper no pudo resolver repo.maven.apache.org.
Se valido tambien la sintaxis JSON de la coleccion (43 peticiones) y XML de pom.xml.
Pendiente: ejecutar el script SQL en una base de prueba vacia y correr la coleccion contra la API real.
Antes de entregar, repetir la instalacion en una carpeta y base de prueba vacias.

Pendiente de adjuntar evidencia real:

- Captura de mascota con datos en el gestor.
- Captura de medicamento con datos en el gestor.
- Captura de veterinario con datos en el gestor.
- Tres capturas de respuestas reales de Postman, una por modelo.

Guardar las capturas en docs/capturas y agregarlas a este README cuando se hayan obtenido.
No se incluyen capturas simuladas ni se declara una ejecucion no comprobada.

## GitHub

Publicar esta carpeta, que contiene pom.xml, como raiz del repositorio.
.gitignore excluye target y archivos del IDE. El repositorio aun debe publicarse y verificarse desde un clon limpio.
